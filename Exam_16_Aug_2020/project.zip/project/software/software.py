# from abc import ABC, abstractmethod

class Software:

    def __init__(self, name ,type ,capacity_consumption ,memory_consumption ):
        self.name = name
        self.type = type  # ("Express" or "Light")
        self.capacity_consumption= capacity_consumption
        self.memory_consumption = memory_consumption

    #
    # def __repr__(self):
    #     return self.name
    #
    # @property
    # def name(self):
    #     return self._name
    #
    # @name.setter
    # def name(self, value):
    #     self._name = value
    #
    # @property
    # def type(self):
    #     return self._type
    #
    # @type.setter
    # def type(self, value):
    #     self._type = value
    #
    # @property
    # def capacity_consumption(self):
    #     return self._capacity_consumption
    #
    # @capacity_consumption.setter
    # def capacity_consumption(self, value):
    #     self._capacity_consumption=value
    #
    # @property
    # def memory_consumption(self):
    #     return self._memory_consumption
    #
    # @memory_consumption.setter
    # def memory_consumption(self, value):
    #     self._memory_consumption= value