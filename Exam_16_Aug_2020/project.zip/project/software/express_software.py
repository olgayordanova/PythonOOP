from project.software.software import Software

class ExpressSoftware(Software):

    def __init__(self,  name ,capacity_consumption_c ,memory_consumption_c):
        super ().__init__ ( name , type="Express" , capacity_consumption=int(capacity_consumption_c), memory_consumption =int(memory_consumption_c*2))



# express_software = ExpressSoftware("HDD", "Test2", 100, 100)
# print(express_software)