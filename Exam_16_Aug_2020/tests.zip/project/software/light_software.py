from project.software.software import Software

class LightSoftware(Software):

    def __init__(self,  name , capacity_consumption_c ,memory_consumption_c):
        super ().__init__ ( name , type = "Light" , capacity_consumption=int(1.5*capacity_consumption_c), memory_consumption = int(memory_consumption_c*0.5))



# l_software = LightSoftware("HDD", "Test2", 100, 100)
# print(l_software)