from project.hardware.heavy_hardware import HeavyHardware
from project.hardware.power_hardware import PowerHardware
from project.software.express_software import ExpressSoftware
from project.software.light_software import LightSoftware


class System:
    _hardware=[]
    _software=[]


    @staticmethod
    def register_power_hardware(name:str, capacity:int, memory:int):
        power_hardware = PowerHardware(name, capacity, memory)
        System._hardware.append(power_hardware)
            # Create a PowerHardware instance and add it to the hardware list


    @staticmethod
    def register_heavy_hardware(name:str, capacity:int, memory:int):
        heavy_hardware = HeavyHardware(name, capacity, memory)
        System._hardware.append(heavy_hardware)
            #Create a HeavyHardware instance and add it to the hardware list

    @staticmethod
    def register_express_software(hardware_name: str, name:str, capacity_consumption:int, memory_consumption:int):
        if hardware_name not in [h.name for h in System._hardware]:
            return f"Hardware does not exist"
        express_software = ExpressSoftware(name, capacity_consumption, memory_consumption)
        hardware_i = [h for h in System._hardware if hardware_name == h.name][0]
        try:
            hardware_i.install ( express_software )
            System._software.append(express_software)
        except:
            return 'Software cannot be installed'

            # •	If the hardware with the given name does NOT exist, return a message "Hardware does not exist"
            # •	Otherwise, create an ExpressSoftware instance,
            # install it on the hardware (if possible) and add it to the software list (if installed successfully)
            # •	If the installation is not possible return the message of the raised Exception

    @staticmethod
    def register_light_software( hardware_name: str, name:str, capacity_consumption:int, memory_consumption:int):
        if hardware_name not in [h.name for h in System._hardware]:
            return f"Hardware does not exist"
        light_software = LightSoftware(name, capacity_consumption, memory_consumption)
        hardware_i = [h for h in System._hardware if hardware_name == h.name][0]
        try:
            hardware_i.install ( light_software )
            System._software.append ( light_software )
        except:
            return 'Software cannot be installed'

    @staticmethod
    def release_software_component ( hardware_name: str, software_name: str):
        if hardware_name not in [h.name for h in System._hardware] or software_name not in [s.name for s in System._software]:
            return f"Some of the components do not exist"

        hardware_i = [h for h in System._hardware if hardware_name == h.name][0]
        software_i = [s for s in System._software if software_name == s.name][0]
        hardware_i.uninstall ( software_i )
        System._software.remove(software_i)


            # •	If both components exist on the system, uninstall the software from the given hardware
            # •	Otherwise, return a message "Some of the components do not exist"

    @staticmethod
    def analyze():
        total_used_memory=sum ([s.memory_consumption for s in System._software])
        total_memory = sum ([h.memory for h in System._hardware])
        total_used_space = sum ([c.capacity_consumption for c in System._software])
        total_capacity = sum ([c.capacity for c in System._hardware])
        res = f"System Analysis\n"
        res += f"Hardware Components: {len(System._hardware)}\n"
        res += f"Software Components: {len ( System._software )}\n"
        res += f"Total Operational Memory: {total_used_memory} / {total_memory}\n"
        res += f"Total Capacity Taken: {total_used_space} / {total_capacity}" #?\n
        return res
    # System Analysis
    # Hardware Components: {count of hardware components}
    # Software Components: {count of software components}
    # Total Operational Memory: {total used memory} / {total memory}
    # Total Capacity Taken: {total used space} / {total capacity}

    @staticmethod
    def system_split():
        res =""
        for h in System._hardware:
            component_name = h.name
            number_express = len([es for es in h.software_components if es.type =="Express"])
            number_light =  len([ls for ls in h.software_components if ls.type =="Light"])
            total_memory_software = sum ([s.memory_consumption for s in h.software_components])
            total_capacity_software =sum ([s.capacity_consumption for s in h.software_components])
            software_components = ', '.join([comp.name for comp in h.software_components]) \
                if h.software_components else 'None'
            res += f"Hardware Component - {component_name}\n"
            res += f"Express Software Components: {number_express}\n"
            res += f"Light Software Components: {number_light}\n"
            res += f"Memory Usage: {total_memory_software} / {h.memory}\n"
            res += f"Capacity Usage: {total_capacity_software} / {h.capacity}\n"
            res += f"Type: {h.type}\n"
            res += f"Software Components: {software_components}" #?\n

        return res


        # Hardware Component - {component name}
        # Express Software Components: {number of the installed express software components}
        # Light Software Components: {number of the installed light software components}
        # Memory Usage: {total memory used of all installed software components} / {total memory of the hardware}
        # Capacity Usage: {total capacity used of all installed software components } / {total capacity of the hardware}
        # Type: {type}
        # Software Components: {names of all software components separated by ', '} (or 'None' if no software components)